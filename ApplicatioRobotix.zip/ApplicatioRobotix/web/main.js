/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


window.addEventListener("load", function() {
    const container = document.querySelector(".container");
    container.classList.remove("fade-in");
  
    const background = document.querySelector(".background");
    background.classList.add("background-animation");
  });
  
  
  
  
  
